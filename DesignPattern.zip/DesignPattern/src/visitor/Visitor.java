package visitor;

public interface Visitor {
    void visitGuNiang(GuNiang g);
    void visitXiaoHuo(XiaoHuo x);
    void visitShaoGong(ShaoGong s);
}
