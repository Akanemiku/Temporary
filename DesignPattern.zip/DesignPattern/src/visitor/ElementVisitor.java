package visitor;

public interface ElementVisitor {
    void accept(Visitor v);
}
