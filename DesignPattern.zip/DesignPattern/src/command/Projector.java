package command;

public class Projector {
    public void ProjectorOn() {
        System.out.println("打开投影仪");
    }

    public void ProjectorOff() {
        System.out.println("关闭投影仪");
    }
}
