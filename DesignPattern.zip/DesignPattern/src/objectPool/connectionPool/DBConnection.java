package objectPool.connectionPool;

public class DBConnection {
    public DBConnection() {
        System.out.println("创建一个连接点");
    }

    public void execute() {
    }
}
