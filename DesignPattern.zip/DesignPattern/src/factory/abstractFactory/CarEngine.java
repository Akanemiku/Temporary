package factory.abstractFactory;

public interface CarEngine {
}
