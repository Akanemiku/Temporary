package factory.abstractFactory;

public class BMWCarFrame implements CarFrame {
    public BMWCarFrame() {
        System.out.println("BMWCarFrame");
    }
}
