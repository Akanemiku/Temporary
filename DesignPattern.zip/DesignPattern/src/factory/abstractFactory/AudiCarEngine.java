package factory.abstractFactory;

public class AudiCarEngine implements CarEngine {
    public AudiCarEngine() {
        System.out.println("AudiCarEngine");
    }
}
