package factory.abstractFactory;

public class AudiCarFrame implements CarFrame {
    public AudiCarFrame() {
        System.out.println("AudiCarFrame");
    }
}
