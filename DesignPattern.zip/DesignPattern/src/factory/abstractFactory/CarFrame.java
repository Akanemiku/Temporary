package factory.abstractFactory;

public interface CarFrame {
}
