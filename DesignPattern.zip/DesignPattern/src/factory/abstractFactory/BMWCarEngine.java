package factory.abstractFactory;

public class BMWCarEngine implements CarEngine {
    public BMWCarEngine() {
        System.out.println("BMWCarEngine");
    }
}
