package factory;

public interface Car {
    void startUp();

    void run();
}
