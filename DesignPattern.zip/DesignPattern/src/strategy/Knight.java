package strategy;

public class Knight extends Role {
    @Override
    public void display() {
        System.out.print("骑士正在使用:");
    }
}
