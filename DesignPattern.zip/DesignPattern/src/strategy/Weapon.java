package strategy;

public interface Weapon {
    void useWeapon();
}
