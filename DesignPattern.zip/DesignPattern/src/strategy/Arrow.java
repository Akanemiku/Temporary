package strategy;

public class Arrow implements Weapon{
    @Override
    public void useWeapon() {
        System.out.println("弓箭");
    }
}
