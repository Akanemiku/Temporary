package strategy;

public class Princess extends Role {
    @Override
    public void display() {
        System.out.print("公主正在使用:");
    }
}
