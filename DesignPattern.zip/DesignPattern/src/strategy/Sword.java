package strategy;

public class Sword implements Weapon {
    @Override
    public void useWeapon() {
        System.out.println("阐释者");
    }
}
