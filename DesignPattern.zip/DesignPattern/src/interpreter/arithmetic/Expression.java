package interpreter.arithmetic;

public interface Expression {
    int interpreter(Context context);
}
