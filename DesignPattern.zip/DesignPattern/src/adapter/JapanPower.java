package adapter;

public class JapanPower {
    public void charge110V() {
        System.out.println("使用日本110V电压充电");
    }
}
