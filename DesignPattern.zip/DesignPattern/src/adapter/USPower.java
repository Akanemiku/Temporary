package adapter;

public class USPower {
    public void charge120V() {
        System.out.println("使用美国120V电压充电");
    }
}
