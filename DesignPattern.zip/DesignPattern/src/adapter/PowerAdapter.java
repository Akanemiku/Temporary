package adapter;

public interface PowerAdapter {
    void charge();
}
