package adapter;

public class ChinaPower {

    public void charge220V() {
        System.out.println("使用中国220V电压充电");
    }
}
