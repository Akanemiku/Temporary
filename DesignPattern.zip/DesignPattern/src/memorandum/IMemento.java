package memorandum;

public interface IMemento {
}
