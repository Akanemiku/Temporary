package memorandum;

public class PhotoState {
    private double length;

    public PhotoState() {
    }

    public double getLength() {
        return length;
    }

    public void setLength(double length) {
        this.length = length;
    }
}
