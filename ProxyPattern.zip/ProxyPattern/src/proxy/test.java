package proxy;

import org.junit.Test;
import proxy.Service.Impl.TeacherServiceImpl;
import proxy.Service.StudentService;
import proxy.Service.TeacherService;

import java.lang.reflect.Proxy;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Logger;

public class test {
    public static Logger logger = Logger.getLogger(test.class.getSimpleName());

    @Test
    public void test1(){

        Role role = new Role("Admin");
        User user = new User("Alan","teacher","123");
        user.grant(role);

        ObjectPool objectPool = new ObjectPool(user);
        TeacherService teacherService = (TeacherService) objectPool.getObject("proxy.Service.TeacherService");
        teacherService.teach(user,new Course("设计模式"));
//        StudentService studentService = (StudentService) objectPool.getObject("proxy.Service.StudentService");
//        studentService.study();
        TeacherService teacherService2 = LogInvocationHandler.getProxyInstance(TeacherServiceImpl.class);
        teacherService2.teach(user,new Course("设计模式"));
    }

    @Test
    public void test2(){
        Role role = new Role("Admin");
        User user = new User("Alan","teacher","123");
        user.grant(role);
        TeacherService teacher = new TeacherServiceImpl(user,new Course("设计模式"));
        TeachInvocationHandler handler = new TeachInvocationHandler();
        handler.bindObject(teacher);

        TeacherService proxy = (TeacherService) Proxy.newProxyInstance
                        (handler.getClass().getClassLoader(),
                        teacher.getClass().getInterfaces(),
                        handler);

    }

    @Test
    public void teat3(){
        SimpleDateFormat dateFormat = new SimpleDateFormat("MMM dd号 E, yyyy [hh:mm:ss a] ");
        System.out.println(dateFormat.format(new Date()));
    }

}
