package proxy;

import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Proxy;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public class ObjectPool {

    private static Map<String, Object> objects = new HashMap<>();
    private TeachInvocationHandler handler = new TeachInvocationHandler();

    private Object objectProxy;
    private User user;
    private Constructor<?> constructor;

    public ObjectPool(User user) {
        this.user = user;
    }

    public Object getObject(String classname) {
        Class clazz;
        if (objects.get(classname) == null) {
            try {
                Properties properties = new Properties();
                InputStream in = ObjectPool.class.getClassLoader().getResourceAsStream("proxy/config.properties");
                properties.load(in);
                String name = properties.getProperty(classname);
                //System.out.println("name:" + name);
                clazz = Class.forName(name);

                constructor = clazz.getConstructor(User.class, Course.class);
                objectProxy = constructor.newInstance(user, new Course("设计模式"));
                handler.bindObject(objectProxy);
                objectProxy = Proxy.newProxyInstance(
                        handler.getClass().getClassLoader(),
                        objectProxy.getClass().getInterfaces(),
                        handler);

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return objectProxy;
    }

}
