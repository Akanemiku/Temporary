package proxy;

import proxy.Service.CourseService;
import proxy.Service.Impl.CourseServiceImpl;
import proxy.Service.Impl.TeacherServiceImpl;
import proxy.Service.TeacherService;

import java.util.logging.Logger;

public class Client {
    public static Logger logger = Logger.getLogger(Client.class.getSimpleName());
    public static void main(String[] args){

        CourseService courseService = LogInvocationHandler.getProxyInstance(CourseServiceImpl.class);
        courseService.openCourse(new Course("设计模式"));

        TeacherService teacherService = LogInvocationHandler.getProxyInstance(TeacherServiceImpl.class);

    }
}
