package proxy.Service.Impl;

import proxy.Course;
import proxy.Service.TeacherService;
import proxy.User;

public class TeacherServiceImpl implements TeacherService {

    private Course course;
    private User user;

    public TeacherServiceImpl(){}

    public TeacherServiceImpl(User user,Course course){
        this.user = user;
        this.course = course;
    }

    @Override
    public void teach(User user,Course course) {
        this.user = user;
        this.course = course;
        System.out.println(user.getName()+"老师教"+course.getName());
    }
}
