package proxy.Service.Impl;

import proxy.Course;
import proxy.Service.StudentService;
import proxy.User;

public class StudentServiceImpl implements StudentService {

    private Course course;
    private User user;

    public StudentServiceImpl(){}

    public StudentServiceImpl(User user,Course course){
        this.user = user;
        this.course = course;
    }

    @Override
    public void study(User user, Course course) {
        this.user = user;
        this.course = course;
        System.out.println(user.getName()+"学生学"+course.getName());
    }
}
