package proxy.Service.Impl;

import proxy.Course;
import proxy.Service.CourseService;

public class CourseServiceImpl implements CourseService {
    private Course course;

    public CourseServiceImpl() {
        System.out.println("执行无参构造函数");
    }

    public CourseServiceImpl(Course course) {
        this.course = course;
        System.out.println("执行有参构造函数");
    }

    @Override
    public void selectCourse(Course course) {
        System.out.println("you have select " + course.getName());
    }

    @Override
    public void auditCourse(Course course) {
        System.out.println("you have auditCourse " + course.getName());
    }

    @Override
    public void openCourse(Course course) {
        System.out.println("you have openCourse " + course.getName());
    }
}
