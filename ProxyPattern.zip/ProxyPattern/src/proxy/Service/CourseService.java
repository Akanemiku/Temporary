package proxy.Service;

import proxy.Course;

public interface CourseService {
    //选课
    void selectCourse(Course course);
    //审批
    void auditCourse(Course course);
    //开课
    void openCourse(Course course);
}
