package proxy.Service;

import proxy.Course;
import proxy.User;

public interface TeacherService {
    void teach(User user, Course course);
}
