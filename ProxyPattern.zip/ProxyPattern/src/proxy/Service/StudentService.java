package proxy.Service;

import proxy.Course;
import proxy.User;

public interface StudentService {
    void study(User user, Course course);
}
