package proxy;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Date;

public class TeachInvocationHandler implements InvocationHandler {

    private Object obj;
    private SimpleDateFormat dateFormat = new SimpleDateFormat("MMM dd号 E, yyyy [hh:mm:ss a] ");

    public void bindObject(Object obj){
        this.obj = obj;
    }



    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        System.err.println(dateFormat.format(new Date()));
        System.err.println("==================正在加载记录==================");
        System.out.println(proxy.getClass().getName());
        System.out.println(method.getClass().getName());
        System.out.println("方法名："+method.getName());
        System.out.println("参数："+args[0]+" "+args[1]);
        System.out.println("调用方法结果：");
        Object invoke = method.invoke(obj, args);
        System.err.println("==================记录加载完毕==================");
        System.err.println(dateFormat.format(new Date()));
        return invoke;
    }
}
